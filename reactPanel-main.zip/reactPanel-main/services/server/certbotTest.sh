sudo certbot certonly --nginx --preferred-challenges http --rsa-key-size 2048 --email gor.s@adroot.io --agree-tos -d testdomain009.xyz -d www.testdomain009.xyz --non-interactive
